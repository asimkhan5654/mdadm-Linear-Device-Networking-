#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>
#include "mdadm.h"
#include "jbod.h"
#include "net.h"

// Static variables for tracking mounting and write permission state
static int mounted = 0;
static int write_permission = 0;

// Function for creating JBOD operations
// Parameters:- disk_id: ID of the disk to operate on, block_id: ID of the block to operate on, command: JBOD command to execute, reserved: Reserved bits for future use, returns: A 32-bit integer representing the JBOD operation
uint32_t create_operation(uint32_t disk_id, uint32_t block_id, uint32_t command, uint32_t reserved) {
    return (reserved << 18) | (command << 12) | (block_id) | (disk_id << 8);
}

// JBOD mounting function
// Returns 1 if the mount operation was successful, -1 otherwise.
int mdadm_mount(void) {
    if (mounted) {
        return -1; // Return -1 if already mounted
    }
    if (jbod_client_operation(create_operation(0, 0, JBOD_MOUNT, 0), NULL) == 0) {
        mounted = 1; // Set mounted state to 1 if mount is successful
        return 1;
    }
    return -1; // Return -1 if mount operation fails
}

// JBOD unmounting function
// Returns 1 if the unmount operation was successful, -1 otherwise.
int mdadm_unmount(void) {
    if (!mounted) {
        return -1; // Return -1 if not mounted
    }
    if (jbod_client_operation(create_operation(0, 0, JBOD_UNMOUNT, 0), NULL) == 0) {
        mounted = 0; // Set mounted state to 0 if unmount is successful
        return 1;
    }
    return -1; // Return -1 if unmount operation fails
}

// Function to grant write permission
// Returns 1 if the operation was successful, -1 otherwise.
int mdadm_write_permission(void) {
    if (write_permission) {
        return -1; // Return -1 if write permission is already granted
    }
    if (jbod_client_operation(create_operation(0, 0, JBOD_WRITE_PERMISSION, 0), NULL) == 0) {
        write_permission = 1; // Set write permission to 1 if operation is successful
        return 1;
    }
    return -1; // Return -1 if write permission operation fails
}

// Function to revoke write permission
// Returns 1 if the operation was successful, -1 otherwise.
int mdadm_revoke_write_permission(void) {
    if (!write_permission) {
        return -1; // Return -1 if write permission is not granted
    }
    if (jbod_client_operation(create_operation(0, 0, JBOD_REVOKE_WRITE_PERMISSION, 0), NULL) == 0) {
        write_permission = 0; // Set write permission to 0 if operation is successful
        return 1;
    }
    return -1; // Return -1 if revoke write permission operation fails
}

// Helper function to perform disk and block seek operations
// Parameters:- disk_id: ID of the disk to seek, block_id: ID of the block to seek, Returns 0 if the seek operations were successful, -1 otherwise.
static int perform_seek(uint32_t disk_id, uint32_t block_id) {
    if (jbod_client_operation(create_operation(disk_id, 0, JBOD_SEEK_TO_DISK, 0), NULL) != 0) {
        return -1; // Return -1 if seek to disk operation fails
    }
    if (jbod_client_operation(create_operation(0, block_id, JBOD_SEEK_TO_BLOCK, 0), NULL) != 0) {
        return -1; // Return -1 if seek to block operation fails
    }
    return 0; // Return 0 if seek operations were successful
}

// Function to read data from JBOD
// Parameters:- start_addr: Starting address to read from, read_len: Length of data to read, read_buf: Pointer to buffer to store the read data, Returns total number of bytes read if successful, -1 otherwise.
int mdadm_read(uint32_t start_addr, uint32_t read_len, uint8_t *read_buf) {
    // Validate parameters and state
    if (!mounted || start_addr + read_len > 1048576 || read_len > 2048 || (read_buf == NULL && read_len != 0)) {
        return -1; // Return -1 if any validation fails
    }

    uint32_t current_addr = start_addr;
    uint32_t bytes_read = 0;

    while (bytes_read < read_len) {
        uint32_t disk_id = current_addr / 65536;
        uint32_t block_id = (current_addr % 65536) / 256;
        uint32_t offset = current_addr % 256;
        uint32_t bytes_to_read = (read_len - bytes_read < 256 - offset) ? (read_len - bytes_read) : (256 - offset);

        uint8_t tempbuf[256];

        // Check if the block is in cache
        if (!cache_enabled() || cache_lookup(disk_id, block_id, tempbuf) == -1) {
            // Perform seek operations if not in cache
            if (perform_seek(disk_id, block_id) != 0) {
                return -1; // Return -1 if seek operation fails
            }
            // Read the block if not in cache
            if (jbod_client_operation(create_operation(0, 0, JBOD_READ_BLOCK, 0), tempbuf) != 0) {
                return -1; // Return -1 if read operation fails
            }
            // Insert the block into cache
            cache_insert(disk_id, block_id, tempbuf);
        }

        // Copy data from the block to the read buffer
        memcpy(read_buf + bytes_read, tempbuf + offset, bytes_to_read);

        bytes_read += bytes_to_read;
        current_addr += bytes_to_read;
    }

    return bytes_read; // Return total number of bytes read
}

// Function to write data to JBOD
// Parameters:- start_addr: Starting address to write to, write_len: Length of data to write, write_buf: Pointer to buffer containing data to write, Returns total number of bytes written if successful, -1 otherwise.
int mdadm_write(uint32_t start_addr, uint32_t write_len, const uint8_t *write_buf) {
    // Validate parameters and state
    if (!mounted || !write_permission || start_addr + write_len > 1048576 || write_len > 2048 || (write_buf == NULL && write_len != 0)) {
        return -1; // Return -1 if any validation fails
    }

    uint32_t current_addr = start_addr;
    uint32_t bytes_written = 0;

    while (bytes_written < write_len) {
        uint32_t disk_id = current_addr / 65536;
        uint32_t block_id = (current_addr % 65536) / 256;
        uint32_t offset = current_addr % 256;
        uint32_t bytes_to_write = (write_len - bytes_written < 256 - offset) ? (write_len - bytes_written) : (256 - offset);

        uint8_t tempbuf[256];

        // Check if the block is in cache
        if (cache_enabled() && cache_lookup(disk_id, block_id, tempbuf) == 1) {
            // Update the block in cache
            memcpy(tempbuf + offset, write_buf + bytes_written, bytes_to_write);
            cache_update(disk_id, block_id, tempbuf);
        } else {
            // Perform seek operations if not in cache
            if (perform_seek(disk_id, block_id) != 0) {
                return -1; // Return -1 if seek operation fails
            }
            // Read the block if not in cache
            if (jbod_client_operation(create_operation(0, 0, JBOD_READ_BLOCK, 0), tempbuf) != 0) {
                return -1; // Return -1 if read operation fails
            }
            // Update the block
            memcpy(tempbuf + offset, write_buf + bytes_written, bytes_to_write);
            // Insert the block into cache
            cache_insert(disk_id, block_id, tempbuf);
        }

        // Perform seek operations to write the updated block
        if (perform_seek(disk_id, block_id) != 0) {
            return -1; // Return -1 if seek operation fails
        }
        // Write the updated block to disk
        if (jbod_client_operation(create_operation(0, 0, JBOD_WRITE_BLOCK, 0), tempbuf) != 0) {
            return -1; // Return -1 if write operation fails
        }

        bytes_written += bytes_to_write;
        current_addr += bytes_to_write;
    }

    return bytes_written; // Return total number of bytes written
}
