#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <err.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include "net.h"
#include "jbod.h"

/* the client socket descriptor for the connection to the server */
int cli_sd = -1;

/* attempts to read n (len) bytes from fd; returns true on success and false on failure. 
It may need to call the system call "read" multiple times to reach the given size len. 
*/
static bool nread(int fd, int len, uint8_t *buf) {
  int total_read = 0;  // Initialize total number of bytes read to 0

  // Handling reading until desired length is reached
  for (int remaining = len; remaining > 0; ) {
    int bytes_read = read(fd, buf + total_read, remaining);  // Reading from file descriptor into buffer

    // Check if read operation failed or reached EOF
    if (bytes_read <= 0) {
      return false;  // Return false if read fails or no more data to read
    }

    // Update total bytes read and remaining bytes to read
    total_read += bytes_read;
    remaining -= bytes_read;
  }

  return true;  // Return true if the entire length has been read successfully
}

/* attempts to write n bytes to fd; returns true on success and false on failure 
It may need to call the system call "write" multiple times to reach the size len.
*/
static bool nwrite(int fd, int len, uint8_t *buf) {
  int total_written = 0;  // Initialize total number of bytes written to 0

  // Handling writing until desired length is reached
  for (int remaining = len; remaining > 0; ) {
    int bytes_written = write(fd, buf + total_written, remaining);  // Writing from buffer to file descriptor

    // Check if write operation failed
    if (bytes_written <= 0) {
      return false;  // Return false if write fails
    }

    // Update the total bytes written and remaining bytes to write
    total_written += bytes_written;
    remaining -= bytes_written;
  }

  return true;  // Return true if the entire length has been written successfully
}


/* Through this function call the client attempts to receive a packet from sd 
(i.e., receiving a response from the server.). It happens after the client previously 
forwarded a jbod operation call via a request message to the server.  
It returns true on success and false on failure. 
The values of the parameters (including op, ret, block) will be returned to the caller of this function: 

op - the address to store the jbod "opcode"  
ret - the address to store the info code (lowest bit represents the return value of the server side calling the corresponding jbod_operation function. 2nd lowest bit represent whether data block exists after HEADER_LEN.)
block - holds the received block content if existing (e.g., when the op command is JBOD_READ_BLOCK)

In your implementation, you can read the packet header first (i.e., read HEADER_LEN bytes first), 
and then use the length field in the header to determine whether it is needed to read 
a block of data from the server. You may use the above nread function here.  
*/
static bool recv_packet(int sd, uint32_t *op, uint8_t *ret, uint8_t *block) {
  uint8_t header[HEADER_LEN];  // Buffer to store the header

  // Attempt to read the header from the socket
  if (nread(sd, HEADER_LEN, header) == false) {
    return false;  // Return false if reading the header fails
  }

  // Extract the operation code from the header
  *op = ntohl(*(uint32_t *)(header));
  *ret = header[4];  // Extract the return code from the header

  // Check if the return code indicates that a data block is present
  if (*ret & 0x02) {
    int bytes_left = JBOD_BLOCK_SIZE;
    uint8_t *block_ptr = block;
    while (bytes_left > 0) {
      int bytes_read = read(sd, block_ptr, bytes_left);
      if (bytes_read <= 0) {
        return false;  // Return false if reading the data block fails
      }
      bytes_left -= bytes_read;
      block_ptr += bytes_read;
    }
  }

  return true;  // Return true if the packet was received successfully
}

/* The client attempts to send a jbod request packet to sd (i.e., the server socket here); 
returns true on success and false on failure. 

op - the opcode. 
block- when the command is JBOD_WRITE_BLOCK, the block will contain data to write to the server jbod system;
otherwise it is NULL.

The above information (when applicable) has to be wrapped into a jbod request packet (format specified in readme).
You may call the above nwrite function to do the actual sending.  
*/
static bool send_packet(int sd, uint32_t op, uint8_t *block) {
  // Allocate memory for the packet with extra space for the block if needed
  uint8_t packet[HEADER_LEN + JBOD_BLOCK_SIZE] = {0};

  // Convert the operation code to network byte order and store it in the packet
  *(uint32_t *)packet = htonl(op);

  // Extract the command part from the operation code
  uint32_t command = (op >> 26) & 0x3F;

  // Check if the command is JBOD_WRITE_BLOCK
  if (command == JBOD_WRITE_BLOCK) {
    // Copy the block data into the packet if needed
    memcpy(packet + HEADER_LEN, block, JBOD_BLOCK_SIZE);
    // Send the entire packet including the block data
    return nwrite(sd, HEADER_LEN + JBOD_BLOCK_SIZE, packet);
  } else {
    // Send only the header part of the packet
    return nwrite(sd, HEADER_LEN, packet);
  }
}



/* attempts to connect to server and set the global cli_sd variable to the
 * socket; returns true if successful and false if not. 
 * this function will be invoked by tester to connect to the server at given ip and port.
 * you will not call it in mdadm.c
*/
bool jbod_connect(const char *ip, uint16_t port) {
  struct sockaddr_in server_addr;  // Structure to hold server address information

  // Create a socket for communication
  cli_sd = socket(AF_INET, SOCK_STREAM, 0);
  if (cli_sd < 0) {
    perror("socket creation failed");  // Print error message if socket creation fails
    return false;
  }

  // Set up the server address structure
  server_addr.sin_family = AF_INET;  // Set address family to AF_INET (IPv4)
  server_addr.sin_port = htons(port);  // Convert port number to network byte order

  // Convert IP address from text to binary form
  if (inet_aton(ip, &server_addr.sin_addr) == 0) {
    perror("IP address conversion failed");  // Print error message if IP conversion fails
    close(cli_sd);  // Close the socket if IP conversion fails
    return false;
  }

  // Attempt to connect to the server
  if (connect(cli_sd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
    perror("connection failed");  // Print error message if connection fails
    close(cli_sd);  // Close the socket if connection fails
    return false;
  }

  return true;  // Return true if connection is successful
}

/* disconnects from the server and resets cli_sd */
void jbod_disconnect(void) {
  if (cli_sd != -1) {  // Check if the client socket descriptor is valid
    close(cli_sd);     // Close the socket connection
    cli_sd = -1;       // Reset the client socket descriptor
  }
}

/* sends the JBOD operation to the server (use the send_packet function) and receives 
(use the recv_packet function) and processes the response. 

The meaning of each parameter is the same as in the original jbod_operation function. 
return: 0 means success, -1 means failure.
*/
int jbod_client_operation(uint32_t op, uint8_t *block) {
  uint8_t ret;  // Variable to store the response

  // Send the packet to the server
  bool send_status = send_packet(cli_sd, op, block);
  if (!send_status) {
    return -1;  // Return failure if sending packet fails
  }

  // Receive the response from the server
  bool recv_status = recv_packet(cli_sd, &op, &ret, block);
  if (!recv_status) {
    return -1;  // Return failure if receiving packet fails
  }

  // Return success if the lowest bit of ret is set, otherwise return failure
  return (ret & 0x01) ? 0 : -1;
}

